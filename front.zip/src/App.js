import './App.css';

import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'

import Entreprise from './entreprise/entreprise';


function App() {

  return <>

    <Entreprise/>
  </>
}

export default App;
